import React, { useState } from "react";
import { Phone, Mail, MapPin, CheckCircle2, ChevronRight, Menu } from "lucide-react";

const NAV = [
  { id: "services", label: "Services" },
  { id: "contact", label: "Contact" },
];

const SERVICES = [
  { title: "General Building Works", desc: "All aspects of domestic and commercial building handled with professionalism." },
  { title: "Extensions", desc: "Rear, side, and double-storey extensions with full project management." },
  { title: "Bathrooms", desc: "Complete bathroom installations and refurbishments, modern and functional." },
  { title: "Renovations", desc: "Full property renovations including kitchens, interiors, and layout reconfiguration." },
  { title: "Loft Conversions", desc: "Maximise your space with bespoke loft conversions designed to your needs." },
  { title: "Garden Rooms", desc: "Custom-built garden offices, gyms, and living spaces." },
  { title: "Roof Works", desc: "New roofs, slate, tiles, leadwork, and roof repairs with guaranteed workmanship." },
  { title: "External Rendering", desc: "Insulated render systems, traditional render, and pebble dash removal." },
  { title: "Full Refurbishment & M&E", desc: "Comprehensive refurbishments including plumbing, electrics, and all trades." },
];

export default function App() {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-800">
      <header className="sticky top-0 z-40 w-full border-b border-zinc-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-6">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Pro100 Build Logo" className="h-10 w-10" />
            <div className="leading-tight">
              <div className="text-lg font-bold tracking-tight">PRO100 BUILD</div>
              <div className="text-xs text-zinc-500">Royston · SG8 · UK</div>
            </div>
          </div>
          <nav className="hidden items-center gap-6 md:flex">
            {NAV.map((n) => (
              <a key={n.id} href={`#${n.id}`} className="text-sm text-zinc-600 hover:text-zinc-900">{n.label}</a>
            ))}
            <a href="#contact" className="rounded-xl bg-black px-4 py-2 text-sm font-semibold text-white shadow hover:bg-zinc-800">Get a quote</a>
          </nav>
          <button className="inline-flex items-center md:hidden" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
            <Menu className="h-6 w-6" />
          </button>
        </div>
        {open && (
          <div className="border-t border-zinc-200 bg-white md:hidden">
            <div className="mx-auto grid max-w-7xl gap-2 px-4 py-3 md:px-6">
              {NAV.map((n) => (
                <a key={n.id} href={`#${n.id}`} onClick={() => setOpen(false)} className="rounded-lg px-2 py-2 text-sm text-zinc-700 hover:bg-zinc-50">{n.label}</a>
              ))}
              <a href="#contact" onClick={() => setOpen(false)} className="rounded-lg bg-black px-3 py-2 text-center text-sm font-semibold text-white hover:bg-zinc-800">Get a quote</a>
            </div>
          </div>
        )}
      </header>

      <section className="bg-gradient-to-br from-zinc-900 via-black to-zinc-800 text-white">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-20 md:grid-cols-2 md:px-6 lg:py-28">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight sm:text-5xl">Your Complete Construction Partner</h1>
            <p className="mt-4 max-w-xl text-zinc-300">From extensions and bathrooms to full refurbishments with plumbing & electrics — PRO100 BUILD delivers quality every step of the way.</p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <a href="#contact" className="group inline-flex items-center rounded-xl bg-black px-5 py-3 font-semibold text-white shadow hover:bg-zinc-700">
                Request a free quote
                <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </a>
              <a href="#services" className="inline-flex items-center rounded-xl px-5 py-3 font-semibold text-white/90 hover:bg-white/10">
                Our services
              </a>
            </div>
            <div className="mt-6 flex flex-wrap gap-4 text-sm text-zinc-300">
              <span className="inline-flex items-center gap-2"><CheckCircle2 className="h-4 w-4"/> Fully insured</span>
              <span className="inline-flex items-center gap-2"><CheckCircle2 className="h-4 w-4"/> Itemised quotes</span>
              <span className="inline-flex items-center gap-2"><CheckCircle2 className="h-4 w-4"/> Reliable timelines</span>
              <span className="inline-flex items-center gap-2"><CheckCircle2 className="h-4 w-4"/> Certified works & warranty provided</span>
            </div>
          </div>
          <div>
            <img src="/hero-image.jpg" alt="Pro100 Build projects" className="rounded-2xl shadow-lg ring-1 ring-zinc-700" />
          </div>
        </div>
      </section>

      <section id="services" className="mx-auto max-w-7xl px-4 py-16 md:px-6">
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Our Services</h2>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s) => (
            <div key={s.title} className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-zinc-600">{s.desc}</p>
              <p className="mt-2 text-xs text-zinc-500">All works certified and warranty provided.</p>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="bg-zinc-50">
        <div className="mx-auto max-w-7xl px-4 py-16 md:px-6">
          <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Contact Us</h2>
          <ul className="mt-6 space-y-3 text-sm text-zinc-700">
            <li className="flex items-center gap-2"><Phone className="h-4 w-4"/> <a href="tel:+447470387637">07470 387637</a></li>
            <li className="flex items-center gap-2"><Mail className="h-4 w-4"/> <a href="mailto:Pro100build@gmail.com">Pro100build@gmail.com</a></li>
            <li className="flex items-center gap-2"><MapPin className="h-4 w-4"/> 8 Cromwell Way, SG8 7FJ, Royston, UK</li>
          </ul>

          <form className="mt-8 grid gap-4 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm"
            action="https://formspree.io/f/your-id" method="POST">
            <div>
              <label htmlFor="name" className="text-sm font-medium">Name</label>
              <input id="name" name="name" required className="mt-1 w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-zinc-900" />
            </div>
            <div>
              <label htmlFor="email" className="text-sm font-medium">Email</label>
              <input id="email" name="email" type="email" required className="mt-1 w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-zinc-900" />
            </div>
            <div>
              <label htmlFor="phone" className="text-sm font-medium">Phone</label>
              <input id="phone" name="phone" className="mt-1 w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-zinc-900" />
            </div>
            <div>
              <label htmlFor="message" className="text-sm font-medium">Project details</label>
              <textarea id="message" name="message" rows="5" className="mt-1 w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-zinc-900" placeholder="Type of work, location, timings, budget…"></textarea>
            </div>
            <button type="submit" className="rounded-xl bg-black px-5 py-3 font-semibold text-white shadow hover:bg-zinc-800">Send</button>
            <p className="text-xs text-zinc-500">By sending this form you agree to our privacy policy.</p>
          </form>
        </div>
      </section>

      <footer className="border-t border-zinc-200 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-8 text-sm text-zinc-600 md:flex-row md:px-6">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Pro100 Build Logo" className="h-6 w-6" />
            <span className="font-medium">PRO100 BUILD</span>
            <span>· Royston SG8</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="#contact" className="inline-flex items-center gap-1 rounded-lg bg-black px-3 py-1.5 font-semibold text-white hover:bg-zinc-800">
              <Phone className="h-4 w-4"/> Get a quote
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
